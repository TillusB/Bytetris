﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OBlock : Block {
    //The OBlock typically does not rotate!
    public override void Rotate()
    {
        return;
    }

}
